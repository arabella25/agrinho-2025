let perguntas = [
  {
    pergunta: "Onde é mais comum encontrar grandes plantações de soja?",
    respostaCorreta: "campo"
  },
  {
    pergunta: "Qual ambiente é mais propício para arranha-céus e shoppings?",
    respostaCorreta: "cidade"
  },
  {
    pergunta: "Onde o ar costuma ser mais puro e as estrelas mais visíveis?",
    respostaCorreta: "campo"
  },
  {
    pergunta: "Qual local é o centro de indústrias e empresas de tecnologia?",
    respostaCorreta: "cidade"
  },
  {
    pergunta: "Onde a criação de gado leiteiro é uma atividade principal?",
    respostaCorreta: "campo"
  },
  {
    pergunta: "Qual ambiente oferece mais opções de transporte público?",
    respostaCorreta: "cidade"
  },
  {
    pergunta: "Onde é mais fácil encontrar rios e cachoeiras naturais?",
    respostaCorreta: "campo"
  },
  {
    pergunta: "Qual local tem maior acesso a universidades e hospitais especializados?",
    respostaCorreta: "cidade"
  },
  {
    pergunta: "Onde a agricultura familiar é uma importante fonte de renda?",
    respostaCorreta: "campo"
  },
  {
    pergunta: "Qual ambiente é conhecido por ter uma vida noturna agitada?",
    respostaCorreta: "cidade"
  }
];

let indicePerguntaAtual = 0;
let pontos = 0;
let feedback = "";
let jogoIniciado = false;

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(24);
  noStroke(); // Remove as bordas para os botões
}

function draw() {
  background(220);

  if (!jogoIniciado) {
    exibirTelaInicial();
  } else {
    exibirPergunta();
    exibirBotoesResposta();
    exibirPontuacao();
    exibirFeedback();
  }
}

function exibirTelaInicial() {
  fill(50);
  text("Festejando a Conexão do Campo e da Cidade!", width / 2, height / 2 - 50);
  text("Clique para começar!", width / 2, height / 2 + 20);
}

function exibirPergunta() {
  fill(50);
  text(perguntas[indicePerguntaAtual].pergunta, width / 2, height / 2 - 80);
}

function exibirBotoesResposta() {
  // Botão Campo
  fill(46, 204, 113); // Verde
  rect(width / 2 - 120, height / 2 + 20, 100, 50, 10); // x, y, largura, altura, raio borda
  fill(255);
  text("Campo", width / 2 - 70, height / 2 + 45);

  // Botão Cidade
  fill(52, 152, 219); // Azul
  rect(width / 2 + 20, height / 2 + 20, 100, 50, 10);
  fill(255);
  text("Cidade", width / 2 + 70, height / 2 + 45);
}

function exibirPontuacao() {
  fill(50);
  textSize(18);
  text("Pontos: " + pontos, width / 2, 30);
  textSize(24); // Volta ao tamanho original
}

function exibirFeedback() {
  if (feedback !== "") {
    if (feedback === "Certo!") {
      fill(39, 174, 96); // Verde mais escuro
    } else {
      fill(231, 76, 60); // Vermelho
    }
    textSize(30);
    text(feedback, width / 2, height / 2 + 150);
    textSize(24); // Volta ao tamanho original
  }
}

function mousePressed() {
  if (!jogoIniciado) {
    jogoIniciado = true;
    return; // Sai da função para não processar cliques de resposta na tela inicial
  }

  // Verifica clique no botão Campo
  if (mouseX > width / 2 - 120 && mouseX < width / 2 - 20 &&
      mouseY > height / 2 + 20 && mouseY < height / 2 + 70) {
    verificarResposta("campo");
  }

  // Verifica clique no botão Cidade
  if (mouseX > width / 2 + 20 && mouseX < width / 2 + 120 &&
      mouseY > height / 2 + 20 && mouseY < height / 2 + 70) {
    verificarResposta("cidade");
  }
}

function verificarResposta(respostaSelecionada) {
  if (respostaSelecionada === perguntas[indicePerguntaAtual].respostaCorreta) {
    pontos++;
    feedback = "Certo!";
  } else {
    feedback = "Errado!";
  }
  
  // Próxima pergunta após um pequeno atraso
  setTimeout(() => {
    indicePerguntaAtual++;
    feedback = ""; // Limpa o feedback
    if (indicePerguntaAtual < perguntas.length) {
      // Continua o jogo
    } else {
      // Jogo terminou
      jogoIniciado = false; // Volta para a tela inicial ou exibe um resultado final
      feedback = "Fim de jogo! Você fez " + pontos + " pontos!";
      indicePerguntaAtual = 0; // Reinicia para a próxima partida
      pontos = 0; // Reinicia os pontos
    }
  }, 1000); // Espera 1 segundo antes de ir para a próxima pergunta
}